<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class Smartsupp extends Module
{
    public function __construct()
    {
        $this->name = 'smartsupp';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Mohicano';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = ['min' => '1.6', 'max' => _PS_VERSION_];

        parent::__construct();

        $this->displayName = $this->l('Smartsupp Live Chat');
        $this->description = $this->l('Agrega el chat de Smartsupp a tu tienda.');
    }

    public function install()
    {
        Configuration::updateValue('SMARTSUPP_KEY', '7c4d3cf80b87d3541b635518dd8a47c1978a7120');
        Configuration::updateValue('SMARTSUPP_ENABLED', 1);
        return parent::install() && $this->registerHook('displayFooter');
    }

    public function uninstall()
    {
        Configuration::deleteByName('SMARTSUPP_KEY');
        Configuration::deleteByName('SMARTSUPP_ENABLED');
        return parent::uninstall();
    }

    public function getContent()
    {
        $output = '';
        if (Tools::isSubmit('submitSmartsupp')) {
            Configuration::updateValue('SMARTSUPP_KEY', Tools::getValue('SMARTSUPP_KEY'));
            Configuration::updateValue('SMARTSUPP_ENABLED', (int) Tools::getValue('SMARTSUPP_ENABLED'));
            $output .= $this->displayConfirmation($this->l('Configuracion guardada.'));
        }
        $fields_form = [[
            'form' => [
                'legend' => ['title' => $this->l('Smartsupp Live Chat')],
                'input' => [
                    [
                        'type' => 'switch',
                        'label' => $this->l('Activar chat'),
                        'name' => 'SMARTSUPP_ENABLED',
                        'values' => [
                            ['id' => 'on', 'value' => 1, 'label' => $this->l('Si')],
                            ['id' => 'off', 'value' => 0, 'label' => $this->l('No')],
                        ],
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Clave de Smartsupp'),
                        'name' => 'SMARTSUPP_KEY',
                        'size' => 60,
                        'required' => true,
                    ],
                ],
                'submit' => ['title' => $this->l('Guardar')],
            ],
        ]];
        $helper = new HelperForm();
        $helper->submit_action = 'submitSmartsupp';
        $helper->fields_value['SMARTSUPP_KEY'] = Configuration::get('SMARTSUPP_KEY');
        $helper->fields_value['SMARTSUPP_ENABLED'] = Configuration::get('SMARTSUPP_ENABLED');
        return $output . $helper->generateForm($fields_form);
    }

    public function hookDisplayFooter()
    {
        if (!(int) Configuration::get('SMARTSUPP_ENABLED')) {
            return '';
        }
        $key = pSQL(Configuration::get('SMARTSUPP_KEY'));
        return '<!-- Smartsupp Live Chat -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = \'' . $key . '\';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName(\'script\')[0];c=d.createElement(\'script\');
  c.type=\'text/javascript\';c.charset=\'utf-8\';c.async=true;
  c.src=\'https://www.smartsuppchat.com/loader.js?\';s.parentNode.insertBefore(c,s);
})(document);
</script>
<noscript>Powered by <a href="https://www.smartsupp.com" target="_blank">Smartsupp</a></noscript>';
    }
}
