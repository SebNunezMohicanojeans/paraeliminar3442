<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class Mj_Smartsupp extends Module
{
    public function __construct()
    {
        $this->name = 'mj_smartsupp';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Mohicano';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = ['min' => '1.6', 'max' => _PS_VERSION_];

        parent::__construct();

        $this->displayName = $this->l('Mohicano Smartsupp Chat');
        $this->description = $this->l('Agrega el chat de Smartsupp a tu tienda.');
    }

    public function install()
    {
        Configuration::updateValue('MJ_SMARTSUPP_KEY', '7c4d3cf80b87d3541b635518dd8a47c1978a7120');
        Configuration::updateValue('MJ_SMARTSUPP_ENABLED', 1);
        return parent::install() && $this->registerHook('displayFooter');
    }

    public function uninstall()
    {
        Configuration::deleteByName('MJ_SMARTSUPP_KEY');
        Configuration::deleteByName('MJ_SMARTSUPP_ENABLED');
        return parent::uninstall();
    }

    public function getContent()
    {
        $output = '';
        if (Tools::isSubmit('submitMjSmartsupp')) {
            Configuration::updateValue('MJ_SMARTSUPP_KEY', Tools::getValue('MJ_SMARTSUPP_KEY'));
            Configuration::updateValue('MJ_SMARTSUPP_ENABLED', (int) Tools::getValue('MJ_SMARTSUPP_ENABLED'));
            $output .= $this->displayConfirmation($this->l('Configuracion guardada.'));
        }
        $fields_form = [[
            'form' => [
                'legend' => ['title' => $this->l('Smartsupp Chat')],
                'input' => [
                    [
                        'type' => 'switch',
                        'label' => $this->l('Activar chat'),
                        'name' => 'MJ_SMARTSUPP_ENABLED',
                        'values' => [
                            ['id' => 'on', 'value' => 1, 'label' => $this->l('Si')],
                            ['id' => 'off', 'value' => 0, 'label' => $this->l('No')],
                        ],
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Clave de Smartsupp'),
                        'name' => 'MJ_SMARTSUPP_KEY',
                        'size' => 60,
                        'required' => true,
                    ],
                ],
                'submit' => ['title' => $this->l('Guardar')],
            ],
        ]];
        $helper = new HelperForm();
        $helper->submit_action = 'submitMjSmartsupp';
        $helper->fields_value['MJ_SMARTSUPP_KEY'] = Configuration::get('MJ_SMARTSUPP_KEY');
        $helper->fields_value['MJ_SMARTSUPP_ENABLED'] = Configuration::get('MJ_SMARTSUPP_ENABLED');
        return $output . $helper->generateForm($fields_form);
    }

    public function hookDisplayFooter()
    {
        if (!(int) Configuration::get('MJ_SMARTSUPP_ENABLED')) {
            return '';
        }
        $key = pSQL(Configuration::get('MJ_SMARTSUPP_KEY'));
        return '<!-- Smartsupp Live Chat -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = \'' . $key . '\';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName(\'script\')[0];c=d.createElement(\'script\');
  c.type=\'text/javascript\';c.charset=\'utf-8\';c.async=true;
  c.src=\'https://www.smartsuppchat.com/loader.js?\';s.parentNode.insertBefore(c,s);
})(document);
</script>
<noscript>Powered by <a href="https://www.smartsupp.com" target="_blank">Smartsupp</a></noscript>';
    }
}
